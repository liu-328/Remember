def send(test):

    print("正在发送：%s ..." % test)



