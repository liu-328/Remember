def receive():

    return "正在接收文件 ..."

